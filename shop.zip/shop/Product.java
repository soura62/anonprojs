package project.shop;

public class Product {

	static  int count=0;
	double price;
	private String productId;
	public Product( double price) {
		super();
		this.productId = productId;
		this.price = price;
	}
	
	
	
	
}
