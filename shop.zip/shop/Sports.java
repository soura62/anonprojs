package project.shop;

public class Sports extends Product {

	public Sports(double price) {
		super(price);
		// TODO Auto-generated constructor stub
	}

}
