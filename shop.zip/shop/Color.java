package project.shop;

public enum Color {
RED,BLUE,GREEN,YELLOW
}
