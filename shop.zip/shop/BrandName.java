package project.shop;

public enum BrandName {

	ZARA,MAX,LEE,POLO
	
	
}
