package project.shop;

public class Clothing extends Product{

	public Clothing(double price) {
		super(price);
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
